import numpy as np


class Knn:
    def __init__(self, n_neighbors, metric='minkowski', p=2, weights='uniform'):
        self.n_neighbors = n_neighbors
        self.p = p
        self.metric = metric
        self.weights = weights
        if metric != 'minkowski' and metric != 'euclidean' and metric != 'manhattan':
            raise ValueError('No se dispone de esa métrica.')

    def fit(self, X, y):
        if X.shape[0] != y.shape[0]:
            raise ValueError('Las dimensiones de los vectores X e y deben coincidir.')
        self.X = X
        self.y = y

    def _manhattan_distance(self, point):
        return np.sum(abs(self.X-point), axis=1)

    def _euclidean_distance(self, point):
        return np.sqrt(np.sum((self.X-point)**2, axis=1))

    def _minkowski_distance(self, point):
        return (np.sum(abs(self.X-point)**self.p, axis=1))**(1/self.p)

    def _uniform_weights(self, distances):
        return np.array([(1, y) for d, y in np.ndenumerate(distances)])

    def _distance_weights(self, distances):
        return np.array([(1 / y, y) if y != 0 else (1, y) for d, y in np.ndenumerate(distances)])

    def _predict_point(self, point):
        # Calcula distancias
        if self.metric == 'minkowski':
            distances = self._minkowski_distance(point)
        elif self.metric == 'euclidean':
            distances = self._euclidean_distance(point)
        elif self.metric == 'manhattan':
            distances = self._manhattan_distance(point)
        # Calcula los pesos de cada punto
        if self.weights == 'uniform':
            distances = self._uniform_weights(distances)
        elif self.weights == 'distance':
            distances = self._distance_weights(distances)
        # E identifica a los vecinos cercanos
        indices = np.argsort(distances[:, 1], axis=0)
        labels = np.unique(self.y[indices[:self.n_neighbors]])
        if len(labels) == 1:
            closest = np.unique(labels)
        else:
            counts = np.zeros((max(labels)+1, 2))
            for i in range(self.n_neighbors):
                counts[self.y[indices[i]], 0] += distances[indices[i], 0]
                counts[self.y[indices[i]], 1] = self.y[indices[i]]
            closest = counts[np.argmax(counts[:, 0]), 1]
        return closest

    def predict(self, x):
        closest = np.zeros(len(x), dtype=int)
        for n in range(len(x)):
            closest[n] = self._predict_point(x[n])
        return closest
